[Assignment Document](https://docs.google.com/document/d/1KjbbRTm-VEmuzDHNKjDIjuBoWpelE_rD_hjM5KFZBOs/edit?usp=sharing)

## Requirements
- Java 11
- Maven 3.9.x

